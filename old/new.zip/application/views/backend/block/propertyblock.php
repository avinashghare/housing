<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editproperty?id=').$before->id; ?>">Property Details</a></li>
<li><a href="<?php echo site_url('site/viewpropertyimage?id=').$before->id; ?>">Property Images</a></li>
<li><a href="<?php echo site_url('site/viewpropertygeolocation?id=').$before->id; ?>">Property Geo Locations</a></li>
<li><a href="<?php echo site_url('site/viewpropertyenquiry?id=').$before->id; ?>">Property Enquiries</a></li>
<!--
<li><a href="<?php echo site_url('site/editaddress?id=').$before->id; ?>">Address</a></li>
<li><a href="<?php echo site_url('site/viewuserinterestevents?id=').$before->id; ?>">User Interest Events</a></li>
-->
</ul>
</div>
</section>